public class DirectoresInvitados {
    private String DNI;
    private String nombre;
    private String apellido;
    private int cantPeliculasDirigidas;


    public DirectoresInvitados(String DNI, String nombre, String apellido, int cantPeliculasDirigidas) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cantPeliculasDirigidas = cantPeliculasDirigidas;
    }

    public DirectoresInvitados() {
    }


    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getCantPeliculasDirigidas() {
        return cantPeliculasDirigidas;
    }

    public void setCantPeliculasDirigidas(int cantPeliculasDirigidas) {
        this.cantPeliculasDirigidas = cantPeliculasDirigidas;
    }

    public void aumentarPeliculasDirigidas(int n){
        cantPeliculasDirigidas=+n;
    }

    public void restarPeliculasDirigidas(int n){
        cantPeliculasDirigidas=-n;
    }

    @Override
    public String toString() {
        return "DirectoresInvitados{" +
                "DNI='" + DNI + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", cantPeliculasDirigidas=" + cantPeliculasDirigidas +
                '}';
    }
}

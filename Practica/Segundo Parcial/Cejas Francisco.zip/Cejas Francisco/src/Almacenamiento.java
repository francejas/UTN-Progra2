import java.util.LinkedHashSet;
import java.util.Set;

public class Almacenamiento <T> {

    private Set<T> almacenamientoSet;

    public Almacenamiento() {
        this.almacenamientoSet = new LinkedHashSet<>();
    }

    public Set<T> getAlmacenamientoSet() {
        return almacenamientoSet;
    }

    public void setAlmacenamientoSet(Set<T> almacenamientoSet) {
        this.almacenamientoSet = almacenamientoSet;
    }

    public boolean agregar (T elemento){
        return almacenamientoSet.add(elemento);
    }

    public boolean eliminar (T elemento){
        return almacenamientoSet.remove(elemento);
    }


    public void mostrar (){

    }


}

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class GestorJSNONPelicula {
    private String nomJSON = "pelicula.json";

    public GestorJSNONPelicula() {
    }

    public JSONObject serializar(PeliculasParticipantes p){
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject();
            jsonObject.put("ID",p.getID());
            jsonObject.put("titulo",p.getTitulo());
            jsonObject.put("anioEstreno",p.getAnioEstreno());
            jsonObject.put("mesEstreno",p.getTitulo());
        }catch (JSONException e){
            e.printStackTrace();
        }
        return jsonObject;
    }

    public void peliculaArchivo (PeliculasParticipantes p){
        OperacionLecturaEscritura.grabar(nomJSON,serializar(p));
    }

    public PeliculasParticipantes deserializar (JSONObject jsonObject){
        PeliculasParticipantes p = new PeliculasParticipantes();
        try {
           p.setID(jsonObject.getString("ID"));
           p.setTitulo(jsonObject.getString("titulo"));
           p.setAnioEstreno(jsonObject.getInt("anioEstreno"));
           p.setMesEstreno(jsonObject.getInt("mesEstreno"));
        }catch (JSONException e){
            e.printStackTrace();
        }
        return p;
    }

    public PeliculasParticipantes archivoPelicula(){
        PeliculasParticipantes peliculaLeida = null;
        JSONTokener jsonTokener = OperacionLecturaEscritura.leer(nomJSON);
        try {
            peliculaLeida = deserializar(new JSONObject(jsonTokener));
        }catch (JSONException e){
            e.printStackTrace();
        }
        return peliculaLeida;
    }



}

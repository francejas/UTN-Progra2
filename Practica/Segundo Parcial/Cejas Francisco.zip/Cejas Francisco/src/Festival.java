import java.util.Map;
import java.util.TreeMap;

public class Festival {
    private String nombreFestival;
    private String ciudad;
    private int anio;

    private Map<String, PeliculasParticipantes> mapaPeliculas;
    private Almacenamiento<DirectoresInvitados> directoresInvitados;
    private Almacenamiento<ActoresInvitados> actoresInvitados;

    public Festival(String nombreFestival, String ciudad, int anio) {
        this.nombreFestival = nombreFestival;
        this.ciudad = ciudad;
        this.anio = anio;
        this.mapaPeliculas = new TreeMap<>();
        this.directoresInvitados = new Almacenamiento<>();
        this.actoresInvitados = new Almacenamiento<>();
    }

    public Festival() {
        this.mapaPeliculas = new TreeMap<>();
        this.directoresInvitados = new Almacenamiento<>();
        this.actoresInvitados = new Almacenamiento<>();
    }


    public void agregarPelicula (PeliculasParticipantes pelicula){
        try {
            if (pelicula.getMesEstreno()>12){
                throw new InvalidDateException("El mes no puede ser mas de 12");
            }
            if (pelicula.getMesEstreno()<1){
                throw new InvalidDateException("El mes no puede ser menor que 1");
            }
            if (pelicula.getAnioEstreno()!=anio){
                throw new InvalidDateException("El anio de estreno de la pelicula no coincide con el anio del festival");
            }
            mapaPeliculas.put(pelicula.getID(),pelicula);
        }catch (InvalidDateException e){
            e.toString();
        }

    }

    /*
    public void mostrarPeliculas(){
        for (Map.entry(String, PeliculasParticipantes) entry: mapaPeliculas.entrySet()){
            System.out.printf("Pelicula" + entry);
        }
    }

     */


    public PeliculasParticipantes buscarPeliculaID(String ID){
try {
    mapaPeliculas.get("ID");
}catch (NullPointerException e){
    e.printStackTrace();
}
        return mapaPeliculas.get("ID");
    }
    /*
    public PeliculasParticipantes buscarPeliculaNombre (String nombre){
        for (Map.entry(String, PeliculasParticipantes) entry : mapaPeliculas.entrySet()){

        }
    }

     */

    public void eliminarPeliculaID(String ID){
        if (mapaPeliculas.containsKey("ID")){
            mapaPeliculas.remove(buscarPeliculaID(ID));
        }

    }

    public void eliminarPeliculaPorNombre (String nombre){
        //mapaPeliculas.remove(buscarPeliculaNombre(nombre));
    }


    public void agregarActor(ActoresInvitados actor){
        actoresInvitados.agregar(actor);
    }

    public void eliminarActor (ActoresInvitados actor){
        actoresInvitados.eliminar(actor);
    }

    public void mostrarActores(){
        actoresInvitados.mostrar();
    }

    public void agregarDirector (DirectoresInvitados director){
        directoresInvitados.agregar(director);
    }

    public void eliminarDirector(DirectoresInvitados director){
        directoresInvitados.eliminar(director);
    }

    public void mostrarDirectores (){
        directoresInvitados.mostrar();
    }






}

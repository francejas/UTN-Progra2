public class Main {
    public static void main(String[] args) {

        GestorJSNONPelicula gestorJSNONPelicula = new GestorJSNONPelicula();
        //1
        Festival festival = new Festival();

        //2
        PeliculasParticipantes pelicula1 = new PeliculasParticipantes("1","El hombre lobo",2000,3);
        PeliculasParticipantes pelicula2 = new PeliculasParticipantes("2","El hombre arania",2010,5);
        PeliculasParticipantes pelicula3 = new PeliculasParticipantes("3","Matrix",2007,6);

        ActoresInvitados actor1 = new ActoresInvitados("Agua","Alejandro","Lopez",false);
        ActoresInvitados actor2 = new ActoresInvitados("Fuego","Daniela","Rodriguez",true);
        ActoresInvitados actor3 = new ActoresInvitados("Tierra","Jimena","Avila",true);


        DirectoresInvitados director1 = new DirectoresInvitados("41562325","Paula","Lopilato",5);
        DirectoresInvitados director2 = new DirectoresInvitados("47895632","Rodrigo","Iglesias",3);
        DirectoresInvitados director3 = new DirectoresInvitados("40258956","Nicolas","Smith",1);


        festival.agregarPelicula(pelicula1);
        festival.agregarPelicula(pelicula2);
        festival.agregarPelicula(pelicula3);

        festival.agregarActor(actor1);
        festival.agregarActor(actor2);
        festival.agregarActor(actor3);

        festival.agregarDirector(director1);
        festival.agregarDirector(director2);
        festival.agregarDirector(director3);

        //3
        festival.mostrarActores();
        festival.mostrarDirectores();
        //mostrarPelicula

        //4
        /*
        try {
            PeliculasParticipantes peliculaABuscar =festival.buscarPeliculaID("1");
            System.out.printf(peliculaABuscar.toString());
        } catch (Exception e){
            e.printStackTrace();
        }

         */




        //5
        //PeliculasParticipantes peliculaABuscarPorNombre = festival.buscarPeliculaNombre("El hombre ")

        //6
        festival.eliminarPeliculaID("3");

        //7

        //8

        //9
        festival.eliminarActor(actor1);
        festival.eliminarDirector(director1);

        //10
        gestorJSNONPelicula.peliculaArchivo(pelicula1);
        //11
        gestorJSNONPelicula.archivoPelicula();






    }
}
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class PeliculasParticipantes implements Comparable {
    private String ID;
    private String titulo;
    private int anioEstreno;
    private int mesEstreno;


    public PeliculasParticipantes(String ID, String titulo, int anioEstreno, int mesEstreno) {
        this.ID = ID;
        this.titulo = titulo;
        this.anioEstreno = anioEstreno;
        this.mesEstreno = mesEstreno;
    }

    public PeliculasParticipantes() {
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnioEstreno() {
        return anioEstreno;
    }

    public void setAnioEstreno(int anioEstreno) {
        this.anioEstreno = anioEstreno;
    }

    public int getMesEstreno() {
        return mesEstreno;
    }

    public void setMesEstreno(int mesEstreno) {
        this.mesEstreno = mesEstreno;
    }

    @Override
    public String toString() {
        return "PeliculasParticipantes{" +
                "ID='" + ID + '\'' +
                ", titulo='" + titulo + '\'' +
                ", anioEstreno=" + anioEstreno +
                ", mesEstreno=" + mesEstreno +
                '}';
    }

    public JSONObject toJSON(){
        JSONObject jsnonPelicula = null;
        try {
            jsnonPelicula = new JSONObject();
            jsnonPelicula.put("ID",ID);
            jsnonPelicula.put("titulo",titulo);
            jsnonPelicula.put("anioEstreno",anioEstreno);
            jsnonPelicula.put("mesEstreno",mesEstreno);
        }catch (JSONException e){
            e.printStackTrace();
        }
        return jsnonPelicula;
    }


    //orden ascendente
    @Override
    public int compareTo(Object o) {
        return 0;
    }
}

public class ActoresInvitados {
    private String nombreArtistico;
    private String nombre;
    private String apellido;
    private boolean alojamientoPago;


    public ActoresInvitados(String nombreArtistico, String nombre, String apellido, boolean alojamientoPago) {
        this.nombreArtistico = nombreArtistico;
        this.nombre = nombre;
        this.apellido = apellido;
        this.alojamientoPago = alojamientoPago;
    }

    public ActoresInvitados() {
    }

    public String getNombreArtistico() {
        return nombreArtistico;
    }

    public void setNombreArtistico(String nombreArtistico) {
        this.nombreArtistico = nombreArtistico;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public boolean isAlojamientoPago() {
        return alojamientoPago;
    }

    public void setAlojamientoPago(boolean alojamientoPago) {
        this.alojamientoPago = alojamientoPago;
    }

    @Override
    public String toString() {
        return "ActoresInvitados{" +
                "nombreArtistico='" + nombreArtistico + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", alojamientoPago=" + alojamientoPago +
                '}';
    }
}
